﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace groupchat3._0.Migrations.GroupChat
{
    public partial class comeee : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
