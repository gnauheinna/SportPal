﻿using System.ComponentModel.DataAnnotations;
using System.Drawing.Printing;

namespace groupchat3._0.Models
{
    public class Group
    {
    
        [Key]
        public int GroupId { get; set; }
        public string Name { get; set; }
        public List<UserGroup> UserGroups { get; set; }
        public List<Message> Messages { get; set; }

    }
}
