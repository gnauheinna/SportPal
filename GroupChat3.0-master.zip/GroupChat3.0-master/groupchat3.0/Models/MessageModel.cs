﻿using System.ComponentModel.DataAnnotations;
namespace groupchat3._0.Models
{
    
    public class MessageModel
    {
        // where i defined the database entries
        [Key]
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Content { get; set; }
    }
}
