﻿using System.ComponentModel.DataAnnotations;

namespace groupchat3._0.Models
{
  
    public class UserGroup
    {
        //foreign key for user: property that points to primary key of another class
        [Key]
        public int UserId { get; set; }

        //navigation property for user:allow to easily related entities without need for an explicit join
        public User User { get; set; }
 
        public int GroupId { get; set; }
        public Group Group { get; set; }
    }
}
