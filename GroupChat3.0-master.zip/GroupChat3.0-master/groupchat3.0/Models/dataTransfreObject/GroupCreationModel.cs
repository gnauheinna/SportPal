﻿namespace groupchat3._0.Models.dataTransfreObject
{
    // only used to capture data sent in request 
    public class GroupCreationModel
    {
        public string GroupName { get; set; }
        public List<string> SelectedUsers { get; set; }
    }
}
