﻿using Microsoft.AspNetCore.Mvc;
using groupchat3._0.Models;

using PusherServer;
using System.Threading.Tasks;
using groupchat3._0.Data;

namespace groupchat3._0.Controllers.chat
{
    [ApiController]
    [Route("api/chat")]
    public class ChatController : ControllerBase
    {
        //initialize db and pusher
        private readonly Pusher _pusher;
        private readonly ChatContext _db;

        public ChatController(Pusher pusher, ChatContext db)
        {
            _pusher = pusher;
            _db = db;
        }

        [HttpPost("Postmessages")]
        public async Task<IActionResult> PostMessage([FromBody] MessageModel message)
        {
            // save messages to db and call pusher to send message to users that subscribed to the groupchat

            _db.MessageModel.Add(message); // add message to database
            await _db.SaveChangesAsync(); // save changes

            // notify other clients using Pusher
            await _pusher.TriggerAsync("group_chat", "new_message", message);
            return Ok();
        }
        [HttpGet("Getmessages")]
        public IActionResult GetAllMessages()
        // get messages from the database to display historic mesages

        {

            var messages = _db.MessageModel.ToList(); // fetch all messages form data base

            return Ok(messages);
        }
    }
}
