﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace groupchat3._0.Controllers.groupchat
{
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {
        private readonly GroupChatContext _context;

        public UserController(GroupChatContext context)
        {
            _context = context;
        }

        // Endpoint to get groups for a specific user
        [HttpGet("GetUserGroups/{userId}")]
        public async Task<IActionResult> GetUserGroups(int userId)
        {
            // Check if the user exists
            var userExists = await _context.User.AnyAsync(u => u.UserId == userId);
            if (!userExists)
            {
                return NotFound("User not found.");
            }

            // Retrieve all groups associated with the specified user
            var userGroups = await _context.UserGroup
                .Where(ug => ug.UserId == userId)
                .Include(ug => ug.Group)
                .Select(ug => new
                {
                    GroupId = ug.Group.GroupId,
                    Name = ug.Group.Name
                })
                .ToListAsync();

            return Ok(userGroups);
        }

        [HttpGet("getUserId/{userName}")]
        public async Task<IActionResult> GetUserId(string userName)
        {
            var user = await _context.User.FirstOrDefaultAsync(u => u.Username == userName);

            if (user != null)
            {
                return Ok(user.UserId);
            }

            return NotFound("User not found.");
        }

        [HttpGet("getUserName/{userId}")]
        public async Task<IActionResult> GetUserName(int userId)
        {
            var user = await _context.User.FirstOrDefaultAsync(u => u.UserId == userId);

            if (user != null)
            {
                return Ok(user.Username);
            }
            return NotFound("User not found.");
        }
    }
}
