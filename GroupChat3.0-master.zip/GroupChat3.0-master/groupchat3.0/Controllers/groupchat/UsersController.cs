﻿using groupchat3._0.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.WebSockets;

namespace groupchat3._0.Controllers.groupchat
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly GroupChatContext _context;

        public UsersController(GroupChatContext context)
        {
            _context = context;
        }

        [HttpPost("AddUser")]
        public IActionResult AddUser([FromBody] string userName)
        {
            // check if user exists
            var existingUser = _context.User.FirstOrDefault(u => u.Username == userName);

            if (existingUser != null)
            {
                return BadRequest("user already exists");
            }
            else
            {
                var newUser = new User { Username = userName };
                _context.User.Add(newUser);
                _context.SaveChanges();
                return Ok("User added succesfully");
            }
        }

        [HttpGet("GetUsers")]
        public IActionResult GetAllUsers()
        {
            var users = _context.User.ToList();
            return Ok(users);
        }


    }
}

    

