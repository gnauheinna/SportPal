﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using groupchat3._0.Models;

namespace groupchat3._0.Data
{
    public class ChatContext : DbContext
    {
      
        public ChatContext (DbContextOptions<ChatContext> options)
            : base(options)
        {
        }

        public DbSet<groupchat3._0.Models.MessageModel> MessageModel { get; set; } = default!;
    }
}
