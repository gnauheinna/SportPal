﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using groupchat3._0.Models;

    public class GroupChatContext : DbContext
    {
        public GroupChatContext (DbContextOptions<GroupChatContext> options)
            : base(options)
        {
        }

        public DbSet<groupchat3._0.Models.Group> Group { get; set; } = default!;
        public DbSet<groupchat3._0.Models.Message> Message { get; set; } = default!;
        public DbSet<groupchat3._0.Models.User> User { get; set; } = default!;
        public DbSet<groupchat3._0.Models.UserGroup> UserGroup { get; set; } = default!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Define the many-to-many relationship
        modelBuilder.Entity<UserGroup>()
            .HasKey(ug => new { ug.UserId, ug.GroupId });

        modelBuilder.Entity<UserGroup>()
            .HasOne(ug => ug.User)
            .WithMany(u => u.UserGroups)
            .HasForeignKey(ug => ug.UserId);

        modelBuilder.Entity<UserGroup>()
            .HasOne(ug => ug.Group)
            .WithMany(g => g.UserGroups)
            .HasForeignKey(ug => ug.GroupId);
    }
}
